/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maisha
 */
import java.sql.*;
import javax.swing.JOptionPane;
public class javaconnect {
   Connection conn=null;
   public static Connection ConnecrDb(){
        try{
            Class.forName("org.sqlite.JDBC");//for javaconnection we had to add a jar file named sqlitejdbc-v056.jar
            //for the javaconnection we had copy the path of the project 
            Connection conn=DriverManager.getConnection("jdbc:sqlite:D:\\CSE\\2.1\\SD Project\\Banking_Management_System\\Banking_Management_System\\bank.sqlite");
            return conn;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return  null;
    }
}
